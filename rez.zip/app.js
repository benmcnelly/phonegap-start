Titanium.UI.setBackgroundColor('#000');

// Main App webview
var win1 = Titanium.UI.createWindow();
var webview = Titanium.UI.createWebView({url: 'index.html'});
win1.add(webview);
win1.open();
