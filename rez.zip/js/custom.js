$(document).bind("mobileinit", function(){
  $.extend(  $.mobile , {
 //   ajaxEnabled: false
  });

});
