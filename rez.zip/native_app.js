// this sets the background color of the master UIView (when there are no windows/tab groups on it)
Titanium.UI.setBackgroundColor('#fff');

// create tab group
var tabGroup = Titanium.UI.createTabGroup();



//*************************************************************
// create base UI tab and root window
//
var win1 = Titanium.UI.createWindow({  
    title:'Search',
    backgroundColor:'#fff'
});
var tab1 = Titanium.UI.createTab({  
    icon:'tab-mug.png',
    title:'Search',
    window:win1
});

var searchWebview = Titanium.UI.createWebView({
  url: 'search.html',
});


win1.add(searchWebview);

//************************************************************
// create controls tab and root window
//
var win2 = Titanium.UI.createWindow({  
    title:'Gifts',
    backgroundColor:'#fff'
});
var tab2 = Titanium.UI.createTab({  
    icon:'tab-mug.png',
    title:'Gifts',
    window:win2
});

var giftsWebview = Titanium.UI.createWebView({
  url: 'tokens.html',
});

win2.add(giftsWebview);

//****************************************************
// create test tab and root window
//
var win3 = Titanium.UI.createWindow({  
    title:'Friends',
    backgroundColor:'#fff'
});
var tab3 = Titanium.UI.createTab({  
    icon:'tab-mug.png',
    title:'Friends',
    window:win3
});

//create table view data object for facebook test, for tab 3
var data = [
	{title:'Login/Logout', hasChild:true, test:'../facebook/facebook_login_logout.js'},
	{title:'Query', hasChild:true, test:'../facebook/facebook_query.js'},
	{title:'Properties', hasChild:true, test:'../facebook/facebook_properties.js'},
	{title:'Publish Stream', hasChild:true, test:'../facebook/facebook_publish_stream.js'},
	{title:'Execute', hasChild:true, test:'../facebook/facebook_execute.js'}

];


// create table view
var tableview = Titanium.UI.createTableView({
	data:data
});

// create table view event listener
tableview.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = Titanium.UI.createWindow({
			url:e.rowData.test,
			title:e.rowData.title
		});
		Titanium.UI.currentTab.open(win,{animated:true});
	}
});

// add table view to the window aka Titanium.UI.currentWindow.add(tableview);

win3.add(tableview);



//********************************************************************
//  add tabs
//
tabGroup.addTab(tab1);  
tabGroup.addTab(tab2); 
tabGroup.addTab(tab3);  


// open tab group
tabGroup.open();

